#include <stdio.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#define SIZE 100

using namespace std;

class Plane {
private:
    string type;

public:
    Plane() {
        type = "Unknown";
    }

    Plane(const string& t) : type(t) {}

    string get_type() {
        return type;
    }
};

class PrivatePlane : public Plane {
public:
    PrivatePlane() : Plane("Private Plane") {}
};

class BusinessPlane : public Plane {
public:
    BusinessPlane() : Plane("Business Plane") {}
};

class EconomyPlane : public Plane {
public:
    EconomyPlane() : Plane("Economy Plane") {}
};

class Ticket {
private:
    string route;
    Plane* plane;
    double price;
public:
    Ticket() {
        route = "Unknown";
        plane = nullptr;
        price = 0.0;
    }

    Ticket(const string& r, Plane* pl, double pr) : route(r), plane(pl), price(pr) {}

    void display() {
        cout << "Route: " << route << " Price: " << price << "$" << endl;
        if (plane) {
            cout << "Plane Type: " << plane->get_type() << endl;
        }
        cout << endl;
    }

    string get_route() {
        return route;
    }

    void set_route(const string& r) {
        route = r;
    }

    double get_price() {
        return price;
    }

    void set_price(double pr) {
        price = pr;
    }

    Plane* get_plane() {
        return plane;
    }

    void set_plane(Plane* pl) {
        plane = pl;
    }
};

extern "C" {
    void fill_tickets();
    void show_tickets(char* buffer, int buffer_size);
    bool log_in(char* password);
    void add_route(const char* route, double price, int plane_type);
    void delete_route(int index);
    bool select_route(int index);
    void show_selected(char* buffer, int buffer_size);
    void reload_array();
}

Ticket ticket_Array[SIZE];
Ticket selected[SIZE];

extern "C" {
void fill_tickets() {
    FILE* tickets = fopen("/Users/markoholiak/Desktop/Air_company/Air_company/Tickets.txt", "r");

    int i = 0;
    char temp_route[SIZE];
    char temp_type[SIZE];
    int temp_price;
    double coefficient;

    while (fgets(temp_route, SIZE, tickets) != NULL && i < SIZE) {
        temp_route[strcspn(temp_route, "\n")] = '\0';
        fgets(temp_type, SIZE, tickets);
        temp_type[strcspn(temp_type, "\n")] = '\0';
        fscanf(tickets, "%d", &temp_price);
        fgetc(tickets); // Прочитати символ нового рядка після ціни

        Plane* plane = nullptr;
        if (strcmp(temp_type, "Private Plane") == 0) {
            plane = new PrivatePlane();
            coefficient = 2;
            temp_price *= coefficient;
        } else if (strcmp(temp_type, "Business Plane") == 0) {
            plane = new BusinessPlane();
            coefficient = 1.5;
            temp_price *= coefficient;
        } else if (strcmp(temp_type, "Economy Plane") == 0) {
            coefficient = 1.1;
            temp_price *= coefficient;
            plane = new EconomyPlane();
        }

        Ticket new_Item(temp_route, plane, temp_price);
        ticket_Array[i++] = new_Item;
    }

    fclose(tickets);
}

//int main(){
//    return 0;
//}

void show_tickets(char* buffer, int buffer_size) {
    string tickets_text;
    int i = 0;
    while (ticket_Array[i].get_route() != "Unknown") {
        if (ticket_Array[i].get_route() != "Deleted") {
            tickets_text += "№" + to_string(i + 1) + "\n";
            tickets_text += "Route: " + ticket_Array[i].get_route() + "\n";
            stringstream stream;
            stream << fixed << setprecision(2) << ticket_Array[i].get_price();
            string formatted_price = stream.str();
            tickets_text += "Price: " + formatted_price + "$" + "\n";
            
            if (ticket_Array[i].get_plane()) {
                tickets_text += "Plane Type: " + ticket_Array[i].get_plane()->get_type() + "\n";
            }
            tickets_text += "\n";
        }
        i++;
    }

    strncpy(buffer, tickets_text.c_str(), buffer_size - 1);
    buffer[buffer_size - 1] = '\0';
}


    bool log_in(char* password) {
        FILE* admin = fopen("/Users/markoholiak/Desktop/Air_company/Air_company/Admin.txt", "r");
        if (admin == NULL) {
            return false;
        }

        bool verified = false;
        char password1[50];
        fscanf(admin, "%s", password1);
        fclose(admin);

        if (strcmp(password1, password) == 0) {
            verified = true;
        }

        return verified;
    }

void add_route(const char* route, double price, int plane_type) {
    int j = 0;
    while (ticket_Array[j].get_route() != "Unknown" && ticket_Array[j].get_route() != "Deleted") {
        j++;
        if (j >= SIZE) {
            return;
        }
    }
    string new_route = route;
    double coefficient;
    Plane* plane = nullptr;

    switch (plane_type) {
        case 1:
            plane = new PrivatePlane();
            coefficient = 2;
            price *= coefficient;
            break;
        case 2:
            plane = new BusinessPlane();
            coefficient = 1.5;
            price *= coefficient;
            break;
        case 3:
            plane = new EconomyPlane();
            coefficient = 1.1;
            price *= coefficient;
            break;
        default:
            plane = nullptr;
            break;
    }

    Ticket new_Item(new_route, plane, price);
    ticket_Array[j] = new_Item;
}


    void delete_route(int index) {
        index -= 1;
        if(ticket_Array[index].get_route() == "Deleted" || ticket_Array[index].get_route() == "Unknown"){
            return;
        }
        ticket_Array[index].set_route("Deleted");
        delete ticket_Array[index].get_plane();
    }

    bool select_route(int index){
        index -= 1;
        if(selected[index].get_route() != "Unknown"){
            return false;
        }
        selected[index] = ticket_Array[index];
        return true;
    }

void reload_array(){
    Ticket temp;
    for(int i = 0; i < SIZE; i++){
        selected[i] = temp;
    }
}

void show_selected(char* buffer, int buffer_size){
    string tickets_text;
    int i = 0;
    while (i<SIZE) {
        if (selected[i].get_route() != "Deleted" &&  selected[i].get_route() != "Unknown") {
            tickets_text += "№" + to_string(i + 1) + "\n";
            tickets_text += "Route: " + selected[i].get_route() + "\n";
            stringstream stream;
            stream << fixed << setprecision(2) << selected[i].get_price();
            string formatted_price = stream.str();
            tickets_text += "Price: " + formatted_price + "$" + "\n";
            
            if (selected[i].get_plane()) {
                tickets_text += "Plane Type: " + selected[i].get_plane()->get_type() + "\n";
            }
            tickets_text += "\n";
        }
        i++;
    }

    strncpy(buffer, tickets_text.c_str(), buffer_size - 1);
    buffer[buffer_size - 1] = '\0';
}
}
