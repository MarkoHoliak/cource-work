from PySide6 import QtCore, QtWidgets
from PySide6.QtWidgets import QMessageBox, QDialog, QLineEdit, QLabel, QVBoxLayout, QPushButton, QDialogButtonBox, QComboBox
import ctypes
import sys

# Load the shared library
lib = ctypes.CDLL('./main.so')  # Provide the correct path to the shared library

# Access the C++ functions\
reload_array = lib.reload_array
log_in = lib.log_in
fill_tickets = lib.fill_tickets
show_tickets = lib.show_tickets
add_route = lib.add_route
delete_route = lib.delete_route
select_route = lib.select_route
show_selected = lib.show_selected

# Define argument and return types for the function
show_selected.argtypes = [ctypes.c_char_p, ctypes.c_int]
select_route.argtypes = [ctypes.c_int]
select_route.restypes = None
log_in.argtypes = [ctypes.c_char_p]
log_in.restype = ctypes.c_bool
add_route.argtypes = [ctypes.c_char_p, ctypes.c_double, ctypes.c_int]
delete_route.argtypes = [ctypes.c_int]
delete_route.restype = None
show_tickets.argtypes = [ctypes.c_char_p, ctypes.c_int]
show_tickets.restype = None
reload_array.argtypes = None
reload_array.restype = None

verified = False  # Define the variable 'verified'

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Login")
        self.setFixedSize(300, 150)

        layout = QVBoxLayout(self)

        label = QLabel("Enter password:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)

        button_login = QPushButton("Login")
        button_login.clicked.connect(self.handle_login)

        layout.addWidget(label)
        layout.addWidget(self.password_input)
        layout.addWidget(button_login)

    def handle_login(self):
        password = self.password_input.text().encode()
        verified = log_in(password)
        if verified:
            self.accept()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid password")

class AddRouteDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Add Route")
        self.setFixedSize(600, 350)

        layout = QVBoxLayout(self)

        route_label = QLabel("Enter route:")
        self.route_edit = QLineEdit()
        price_label = QLabel("Enter price:")
        self.price_edit = QLineEdit()
        plane_label = QLabel("Select plane type:")
        self.plane_combobox = QComboBox()
        self.plane_combobox.addItem("Private Plane")
        self.plane_combobox.addItem("Business Plane")
        self.plane_combobox.addItem("Economy Plane")

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        layout.addWidget(route_label)
        layout.addWidget(self.route_edit)
        layout.addWidget(price_label)
        layout.addWidget(self.price_edit)
        layout.addWidget(plane_label)
        layout.addWidget(self.plane_combobox)
        layout.addWidget(button_box)

    def get_route(self):
        return self.route_edit.text()

    def get_price(self):
        return float(self.price_edit.text())

    def get_plane_type(self):
        return self.plane_combobox.currentIndex() + 1

class AdminMenuDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Administrator Menu")
        self.setFixedSize(300, 200)

        layout = QVBoxLayout(self)

        button_add_route = QPushButton("Add Route")
        button_add_route.clicked.connect(self.add_route_dialog)

        button_delete_route = QPushButton("Delete Route")
        button_delete_route.clicked.connect(self.delete_route_dialog)

        layout.addWidget(button_add_route)
        layout.addWidget(button_delete_route)

    def add_route_dialog(self):
        dialog = AddRouteDialog()
        if dialog.exec() == QDialog.Accepted:
            route = dialog.get_route().encode()  # Encode the string as bytes
            price = dialog.get_price()  # Get the price as a float
            plane_type = dialog.get_plane_type()  # Get the plane type
            add_route(route, price, plane_type)  # Pass the plane type to the add_route function
            QMessageBox.information(self, "Add Route", "Route added successfully")

    def delete_route_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Delete Route")
        dialog.setFixedSize(300, 150)

        layout = QVBoxLayout(dialog)

        label = QLabel("Enter index:")
        line_edit = QLineEdit()

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        layout.addWidget(label)
        layout.addWidget(line_edit)
        layout.addWidget(button_box)

        if dialog.exec() == QDialog.Accepted:
            index = int(line_edit.text())
            delete_route(index)
            QMessageBox.information(self, "Delete Route", "Route deleted successfully")

class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Flight Management System")
        self.setFixedSize(400, 400)

        layout = QVBoxLayout(self)

        label_title = QLabel("Flight Management System")
        label_title.setAlignment(QtCore.Qt.AlignCenter)

        button_user = QPushButton("Tickets")
        button_user.clicked.connect(self.show_tickets_dialog)

        button_select = QPushButton("Book ticket")
        button_select.clicked.connect(self.show_select_dialog)

        button_show_selected = QPushButton("Booked ticket")
        button_show_selected.clicked.connect(self.show_selected_dialog)

        button_admin = QPushButton("Administrator")
        button_admin.clicked.connect(self.handle_admin_button_clicked)

        button_top_left = QPushButton("Projected By Marko Holiak")
        button_top_left.setStyleSheet("position: absolute; top: 10px; left: 10px;")  # Set button position
        button_top_left.clicked.connect(self.change_button_color)
        self.color_index = 0  # Initialize color index

        layout.addWidget(button_top_left)          # Add the button to the layout
        layout.addWidget(label_title)
        layout.addWidget(button_user)
        layout.addWidget(button_select)
        layout.addWidget(button_show_selected)
        layout.addWidget(button_admin)

    def handle_admin_button_clicked(self):
        login_dialog = LoginDialog()
        if login_dialog.exec() == QDialog.Accepted:
            admin_dialog = AdminMenuDialog()
            admin_dialog.exec()

    def show_tickets_dialog(self):
        tickets_dialog = QDialog(self)
        tickets_dialog.setWindowTitle("Tickets")
        tickets_dialog.setFixedSize(600, 850)

        layout = QVBoxLayout(tickets_dialog)

        # Create a byte buffer to hold the tickets information
        buffer_size = 1024  # Adjust the buffer size as needed
        buffer = ctypes.create_string_buffer(buffer_size)

        # Call the show_tickets function, passing the buffer and buffer size
        show_tickets(buffer, buffer_size)

        # Convert the buffer to a string
        tickets_text = buffer.value.decode()

        label_tickets = QLabel(tickets_text)
        layout.addWidget(label_tickets)

        tickets_dialog.exec()


    def show_selected_dialog(self):
        tickets_dialog = QDialog(self)
        tickets_dialog.setWindowTitle("Booked Tickets")
        tickets_dialog.setFixedSize(600, 850)

        layout = QVBoxLayout(tickets_dialog)

        # Create a byte buffer to hold the tickets information
        buffer_size = 1024  # Adjust the buffer size as needed
        buffer = ctypes.create_string_buffer(buffer_size)

        # Call the show_tickets function, passing the buffer and buffer size
        show_selected(buffer, buffer_size)

        # Convert the buffer to a string
        tickets_text = buffer.value.decode()

        label_tickets = QLabel(tickets_text)
        label_tickets.setAlignment(QtCore.Qt.AlignTop)
        layout.addWidget(label_tickets)

        tickets_dialog.exec()

    def show_select_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Route")
        dialog.setFixedSize(300, 150)

        layout = QVBoxLayout(dialog)

        label = QLabel("Enter index:")
        line_edit = QLineEdit()

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        layout.addWidget(label)
        layout.addWidget(line_edit)
        layout.addWidget(button_box)

        if dialog.exec() == QDialog.Accepted:
            index = int(line_edit.text())
            a = select_route(index)
            if a == 0:
                QMessageBox.information(self, "Route not selected", "Route selected unsuccessfully")
            QMessageBox.information(self, "Route selected", "Route selected successfully")


    def show_admin_login_dialog(self):
        login_dialog = LoginDialog()
        if login_dialog.exec() == QDialog.Accepted:
            self.show_admin_dialog()

    def show_admin_dialog(self):
        admin_dialog = AdminMenuDialog()  # Create an instance of the AdminMenuDialog
        admin_dialog.exec()

    def change_button_color(self):
        colors = ["red", "green", "blue", "yellow"]  # List of colors
        self.color_index += 1  # Increment color index
        if self.color_index >= len(colors):  # Reset color index if exceeds the length of colors
            self.color_index = 0
        color = colors[self.color_index]  # Get the color based on the index

        sender = self.sender()
        sender.setStyleSheet(f"background-color: {color};")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("Fusion")  # Apply the Fusion style
    fill_tickets()
    reload_array()
    main_window = MainWindow()
    main_window.show()

    sys.exit(app.exec())
